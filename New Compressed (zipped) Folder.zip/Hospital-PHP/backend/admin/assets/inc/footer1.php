<footer class="footer footer-alt">
        <?php echo date ('Y');?> &copy; Hospital Management System</a> 
</footer>